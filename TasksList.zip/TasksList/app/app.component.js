"use strict";
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Dialogs = require("ui/dialogs");
require("rxjs/Rx");
var database_1 = require("./providers/database/database");
var AppComponent = (function () {
    function AppComponent(http, database) {
        this.http = http;
        this.database = database;
        this.Tarea = [];
    }
    AppComponent.prototype.ngOnInit = function () {
        var rows = this.database.getDatabase().executeQuery("Tarea");
        for (var i = 0; i < rows.length; i++) {
            this.Tarea.push(rows[i]);
        }
    };
    AppComponent.prototype.addTarea = function () {
        var _this = this;
        var options = {
            title: "Nuevo",
            message: "Ingrese el titulo del nuevo",
            okButtonText: "Aceptar",
            cancelButtonText: "Cancelar",
            inputType: Dialogs.inputType.text
        };
        Dialogs.prompt(options).then(function (result) {
            _this.getQuote(result.text);
        });
    };

    AppComponent.prototype.deleteTarea = function(){
        var index = this.Tarea.indexOf(Tareas);
        this.Tarea.splice(index, 1);
        // LocalStorage.todos = this.stocks;
    };
    
    AppComponent.prototype.editTarea = function() {
        if (this.isEditing)
            this.Tarea.forEach(t => { t.editing = false; });
        this.isEditing = true;
        Tarea.editing = true;
    //    LocalStorage.todos = this.todoList;
    };

    AppComponent.prototype.doneEditing = function() {
        todo.editing = false;
        this.isEditing = false;
       // LocalStorage.todos = this.todoList;
    };

    AppComponent.prototype.getQuote = function (ticker) {
        var _this = this;
        this.http.get("http://localhost:27017/Tasks/json?symbol=" + ticker)
            .map(function (result) { return JSON.parse(result.json()); })
            .do(function (result) { return console.log("RESULT: ", JSON.stringify(result)); })
            .subscribe(function (result) {
            _this.database.getDatabase().createDocument(result, result.Symbol);
            _this.Tarea.push(result);
        }, function (error) {
            console.log("ERROR: ", error);
        });
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: "my-app",
            templateUrl: "app.component.html",
        }), 
        __metadata('design:paramtypes', [http_1.Http, database_1.Database])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map