"use strict";
var core_1 = require("@angular/core");
var mongojs = require("mongojs");
var db= mongojs("mongodb://localhost:27017/Tasks",["Tareas"]);
core_1.Injectable();
var Database = (function () {
    function Database() {
        if (!this.isInstantiated) {
            this.storage = new db();
            this.storage.createView("Tarea", "1", function (document, emitter) {
                emitter.emit(document._id, document);
            });
            this.isInstantiated = true;
        }
    }
    Database.prototype.getDatabase = function () {
        return this.storage;
    };
    return Database;
}());
exports.Database = Database;
//# sourceMappingURL=database.js.map