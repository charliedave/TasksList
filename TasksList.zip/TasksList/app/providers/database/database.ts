import { Injectable } from "@angular/core";
import { mongodb } from "mongojs";

Injectable()
export class Database {

    private storage: any;
    private isInstantiated: boolean;

    public constructor() {
        if(!this.isInstantiated) {
            this.storage = new monogodb("Tareas");
            this.storage.createView("Tarea", "1", (document, emitter) => {
                emitter.emit(document._id, document);
            });
            this.isInstantiated = true;
        }
    }

    public getDatabase() {
        return this.storage;
    }

}