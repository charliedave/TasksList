import { Component, OnInit } from "@angular/core";
import { Http } from "@angular/http";
import * as Dialogs from "ui/dialogs";
import "rxjs/Rx";
import { Database } from "./providers/database/database";

@Component({
    selector: "my-app",
    templateUrl: "app.component.html",
})
export class AppComponent implements OnInit {

    public Tarea: Array<any>;

    public constructor(private http: Http, private database: Database) {
        this.Tarea = [];
    }

    public ngOnInit() {
        let rows = this.database.getDatabase().executeQuery("Tarea");
        for(let i = 0; i < rows.length; i++) {
            this.Tarea.push(rows[i]);
        }
    }

    public addTarea() {
        let options = {
            title: "Nuevo",
            message: "Ingrese el titulo del nuevo",
            okButtonText: "Aceptar",
            cancelButtonText: "Cancelar",
            inputType: Dialogs.inputType.text
        };
        Dialogs.prompt(options).then((result: Dialogs.PromptResult) => {
            this.getQuote(result.text);
        });
    }
    public deletetarea(todo: Todo) {
        var index = this.Tarea.indexOf(todo);
        this.Tareas.splice(index, 1);
      //  LocalStorage.todos = this.todoList;
    }

    public editTarea(todo: Todo) {
        if (this.isEditing)
            this.Tarea.forEach(t => { t.editing = false; });
       // this.isEditing = true;
        todo.editing = true;
     //   LocalStorage.todos = this.todoList;
    }

    public doneEditing(todo: Todo) {
        todo.editing = false;
      //  this.isEditing = false;
      //  LocalStorage.todos = this.todoList;
    }
    public getQuote(ticker: string) {
        this.http.get("http://localhost:27017/Tasks/json?symbol=" + ticker)
            .map(result => JSON.parse(result.json()))
            .do(result => console.log("RESULT: ", JSON.stringify(result)))
            .subscribe(result => {
                this.database.getDatabase().createDocument(result, result.Symbol);
                this.Tarea.push(result);
            }, error => {
                console.log("ERROR: ", error);
            });
    }
    
}
class Todo {
    private isDone: boolean;
    private todoName: string;
    private isEditing: boolean;

    constructor(name: string, done?: boolean, isEditing?: boolean) {
        this.todoName = name;
        this.done = done ? done : false;
        this.isEditing = isEditing ? isEditing : false;
    }

    public set done(done: boolean) {
        this.isDone = done;
    }

    public get done(): boolean {
        return this.isDone;
    }

    public get name(): string {
        return this.todoName;
    }

    public set name(newName: string) {
        this.todoName = newName;
    }

    public get editing(): boolean {
        return this.isEditing;
    }

    public set editing(newEditing: boolean) {
        this.isEditing = newEditing;
    }
}